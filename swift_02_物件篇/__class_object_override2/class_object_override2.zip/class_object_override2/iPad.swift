//
//  iPad.swift
//  class_object_override2
//
//  Created by KH on 2014/10/27.
//  Copyright (c) 2014年 KH. All rights reserved.
//

import Foundation


class iPad
{
    //wifi連網方法，給予預設的internal權限
    internal func connectInternetWithWifi()
    {
        println("iPad透過Wifi連網...已連結")
    }
}