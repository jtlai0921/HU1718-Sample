//
//  MyController.swift
//  controller
//
//  Created by KH on 2014/9/22.
//  Copyright (c) 2014年 KH. All rights reserved.
//

import Foundation

//透過import，引用UIKit套件
import UIKit


//在此自訂一個名為MyController的Controller，
//其只要透過繼承UIViewController即可，
//所有的Controller皆會繼承自此Controller
class MyController : UIViewController
{
    //改寫viewDidLoad
    override func viewDidLoad()
    {
        //控制Interface Builder底層得view的背景顏色為藍色
        self.view.backgroundColor = UIColor.blueColor()
    }
}
