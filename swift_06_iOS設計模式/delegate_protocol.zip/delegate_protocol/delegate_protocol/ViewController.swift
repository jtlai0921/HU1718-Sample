//
//  ViewController.swift
//  delegate_protocol
//
//  Created by KH on 2014/9/25.
//  Copyright (c) 2014年 KH. All rights reserved.
//

import UIKit

//ViewController為了要能夠接tableView的資料委派工作，
//因此必須實作UITableViewDataSource協定，
//以符合委派的資格，
//在此於繼承的類別後方，
//透過逗號","的方式加上UITableViewDataSource協定
class ViewController: UIViewController, UITableViewDataSource {

    
    @IBOutlet weak var tableView: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        //將self(即ViewController)交給tableView的datasource屬性中，
        //即表示以self去接受tableView的產生資料的委派工作
        self.tableView.dataSource = self
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    
    //實作UITableViewDataSource協定上的tableView:numberOfRowsInSection:方法，
    //以告訴UITableView資料有多少筆
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        //在此回傳10，表示有10筆資料
        return 10
    }

    //實作UITableViewDataSource協定上的tableView:cellForRowAtIndexPath:方法，
    //以產生UITableView每一筆所需顯示的資料列，
    //而每一列將會以UITableViewCell表示，
    //因此將回傳UITableViewCell物件
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        
        //在此建立UITableViewCell物件，
        //並設定每列顯示的文字為列號(透過indexPath.row取得)，
        //最後回傳此UITableViewCell，
        //(在此為了更容易了解程式，以直接建立UITableViewCell的方式取得cell物件，
        //正確的寫法應是可將同性質的UITableViewCell拿來重複使用才對)
        var cell:UITableViewCell = UITableViewCell()
        cell.textLabel?.text = String(indexPath.row)
        return cell
    }

}

