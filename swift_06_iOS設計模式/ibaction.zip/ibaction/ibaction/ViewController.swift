//
//  ViewController.swift
//  ibaction
//
//  Created by KH on 2014/9/23.
//  Copyright (c) 2014年 KH. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    //此方法前面加上一個@IBAction是一個標記，
    //用以標記出此方法是一個IBAction，
    //可以與元件上的事件連結，
    //當事件觸發時，
    //就會呼叫此方法
    @IBAction func touch(sender: AnyObject) {
        //將畫面底色變更為藍色
        self.view.backgroundColor = UIColor.blueColor()
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
}

