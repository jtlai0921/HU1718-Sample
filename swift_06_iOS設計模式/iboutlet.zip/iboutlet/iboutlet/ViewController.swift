//
//  ViewController.swift
//  iboutlet
//
//  Created by KH on 2014/9/23.
//  Copyright (c) 2014年 KH. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    //在此建立一個IBOutlet的button屬性，
    //其型別是UIButton，
    //代表著此為專門對應UIButton的屬性
    @IBOutlet weak var button: UIButton!
    override func viewDidLoad() {
        super.viewDidLoad()
        
        //透過IBOutlet參考到Interface Builder的Button按鈕，
        //將Button按鈕的標題文字變更為Hello
        self.button.setTitle("Hello", forState: UIControlState.Normal)
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
}

