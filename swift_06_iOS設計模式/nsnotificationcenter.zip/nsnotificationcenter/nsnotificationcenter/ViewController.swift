//
//  ViewController.swift
//  nsnotificationcenter
//
//  Created by KH on 2014/9/25.
//  Copyright (c) 2014年 KH. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    
    //宣告一個count屬性，以記錄按鈕按下的次數
    var count:Int = 0
    
    
    @IBOutlet weak var label: UILabel!
    
    @IBAction func touch(sender: AnyObject) {
        //透過defaultCenter()方法，
        //取得NSNotificationCenter物件
        let center:NSNotificationCenter  = NSNotificationCenter.defaultCenter()
        //產生didTouch訊息通知至NSNotificationCenter
        center.postNotificationName("didTouch", object: nil)
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        //透過defaultCenter()方法，
        //取得NSNotificationCenter物件
        let center:NSNotificationCenter  = NSNotificationCenter.defaultCenter()
        
        //self(即目前的Controller)向NSNotificationCenter註冊一個訊息通知，
        //此訊息名為"didTouch"，若收到則執行didCount方法，
        //第1個參數為註冊訊息通知的對象，此為self，
        //第2個selector參數為收到訊息通知後要執行的方法didCount方法，
        //第3個name參數為訊息通知的名稱，
        //第4個參數為訊息通知發生時傳遞至selector(即didCount方法)的物件，
        //在此為nil
        center.addObserver(self, selector: "didCount", name: "didTouch", object: nil)
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }

    
    //宣告didCount方法，
    //當它被呼叫時，
    //count屬性會加1，
    //同時將計數的數值顯示在label上
    func didCount(){
        count = count + 1
        self.label.text = String(count)
    }
    
    
    

}

