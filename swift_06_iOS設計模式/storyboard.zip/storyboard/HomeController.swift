//
//  HomeController.swift
//  storyboard
//
//  Created by KH on 2014/10/9.
//  Copyright (c) 2014年 KH. All rights reserved.
//

import Foundation
import UIKit

//定義HomeController
class HomeController : UIViewController
{
    @IBAction func goTouristRegion(sender: AnyObject) {
        //透過performSegueWithIdentifier方法轉場至觀光區場景，
        //其的第1個參數就是轉場Segue的identifier，
        //performSegueWithIdentifier方法會找到值為"go_tourist_region"的轉場，
        //將場景轉換到觀光區場景，
        //第2個參數為轉場時夾帶的物件，
        //在此設為nil
        self.performSegueWithIdentifier("go_tourist_region", sender: nil)
    }
    
    
    @IBAction func goResturant(sender: AnyObject) {
        //透過performSegueWithIdentifier方法轉場至餐廳場景，
        //其的第1個參數就是轉場Segue的identifier，
        //performSegueWithIdentifier方法會找到值為"go_resturant"的轉場，
        //將場景轉換到餐廳場景，
        //第2個參數為轉場時夾帶的物件，
        //在此設為nil
        self.performSegueWithIdentifier("go_resturant", sender: nil)
    }
    
}