//
//  RestaurantViewController.swift
//  storyboard
//
//  Created by KH on 2014/10/9.
//  Copyright (c) 2014年 KH. All rights reserved.
//

import Foundation
import UIKit

//定義RestaurantViewController
class RestaurantViewController : UIViewController
{

    @IBAction func goHome(sender: AnyObject) {
        //透過dismissViewControllerAnimated方法關閉目前的景場，
        //如此就可以回到上一個家場景，
        //第1個參數表示是否要帶有動畫的方式離開，
        //給予true表示要帶有動畫，
        //第2個參數為場景關閉後執行的closure程式，
        //在此設為nil表示不需執行程式
        self.dismissViewControllerAnimated(true, completion: nil)
    }
}
