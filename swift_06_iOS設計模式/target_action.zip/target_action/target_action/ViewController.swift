//
//  ViewController.swift
//  target_action
//
//  Created by KH on 2014/9/24.
//  Copyright (c) 2014年 KH. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var button: UIButton!
    override func viewDidLoad() {
        super.viewDidLoad()
        
        //透過addTarget的方式設定target-action模式，
        //在此button按鈕透過addTarget，
        //第1個參數指定命令執行的對象為self(即目前的Controller)，
        //第2個參數action則是執行target(也就是目前Controller)的touchAction:方法，
        //此方法有一個冒號":"代表touch方法有一個參數，
        //第3個參數forControlEvent指出Button的哪一個事件被觸發時，
        //才會命令target作事，
        //在此設定為TouchUpInside事件發生時執行
        self.button.addTarget(self, action: "touchAction:", forControlEvents: UIControlEvents.TouchUpInside)
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    //在Controller中準備一個touchAction方法，
    //以在target-action模式下，
    //作為action的執行方法
    func touchAction(sender:AnyObject?){
        //將底層的背景色改為藍色
        self.view.backgroundColor = UIColor.blueColor()
    }


}

